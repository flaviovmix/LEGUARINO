package escola;

import java.util.ArrayList;

public class Professor extends Pessoa{
    String formacaoAcademica;
    double salario;
    
    ArrayList<Disciplica> disciplicas;
    ArrayList<Turma> turmas;
    
    void aplicarAvaliacao() {
        
    }
}